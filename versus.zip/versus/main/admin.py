from django.contrib import admin
from .models import Clients
from .models import Storage
from .models import Equipment
from .models import History

class ClientsAdmin(admin.ModelAdmin):
    list_display = ('clients_name', 'clients_city', 'clients_tin', 'clients_equipment', 'clients_dealer', 'clients_status')
    list_filter = ('clients_dealer', 'clients_deletedate')
    search_fields = ('clients_tin', 'clients_name')
    date_hierarchy = 'clients_createdate'

admin.site.register(Clients, ClientsAdmin)

class StorageAdmin(admin.ModelAdmin):
    list_display = (
        'storage_category',
        'storage_name',
        'storage_bar',
        'storage_ip',
        'storage_number',
        'storage_reserv_number',
        'storage_waiting_number',
        )
    list_filter = ('storage_name', 'storage_bar', 'storage_category')
    search_fields = ('storage_name', 'storage_category')

admin.site.register(Storage, StorageAdmin)

class EquipmentAdmin(admin.ModelAdmin):
    list_display = ('equipment_client', 'equipment_equipment', 'equipment_dealer', 'equipment_createdate', 'equipment_deletedate')
    list_filter = ('equipment_client', 'equipment_deletedate')
    search_fields = ('equipment_client', 'equipment_equipment')
    date_hierarchy = 'equipment_createdate'

admin.site.register(Equipment, EquipmentAdmin)

class HistoryAdmin(admin.ModelAdmin):
    list_display = ('history_name', 'history_city', 'history_tin', 'history_equipment', 'history_dealer', 'history_status')
    list_filter = ('history_dealer', 'history_deletedate')
    search_fields = ('history_tin', 'history_name')
    date_hierarchy = 'history_createdate'

admin.site.register(History, HistoryAdmin)