from typing import ValuesView
from .models import *
from django.forms import ModelForm, TextInput, Select
from django.contrib.auth.models import User, AbstractUser
from django.db.models import Count

class ClientsForm(ModelForm):
    class Meta:
        model = Clients
        fields = ['clients_city', 'clients_name', 'clients_tin', 'clients_equipment']

        widgets = {
            "clients_name": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'ООО "ЭИР-ПАРТ"'
            }),
            "clients_tin": TextInput(attrs={
                'class': 'form-control',
                'type': 'select',
                'maxlength': '12',
                'minlength': '10',
                'placeholder': '7708780985'
            }),
            "clients_city": TextInput(attrs={
                'class': 'form-control form-city',
                'type': 'text',
                'list': 'city',
                'id': 'exampleDataList',
                'placeholder': 'Москва'
            }),
            "clients_equipment": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'ZUV 5,5B, ZUV 22'
            }),
        }

class BackStorageForm(ModelForm):
    class Meta:
        model = Storage
        fields = ['storage_name', 'storage_bar', 'storage_ip', 'storage_category', 'storage_drive_unit', 'storage_performance', 'storage_power', 'storage_outlet_pipe_diameter', 'storage_dimensions', 'storage_mass', 'storage_number', 'storage_reserv_number', 'storage_image']

        widgets = {
            "storage_name": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'list': 'city',
                'placeholder': 'Модель'
            }),
            "storage_bar": Select(attrs={
                'class': 'form-select',
                'type': 'select',
                'placeholder': 'Давление'
            }),
            "storage_ip": Select(attrs={
                'class': 'form-select',
                'type': 'select',
                'placeholder': 'IP'
            }),
            "storage_category": Select(attrs={
                'class': 'form-select',
                'type': 'select',
                'placeholder': 'Категория'
            }),
            "storage_drive_unit": Select(attrs={
                'class': 'form-select',
                'type': 'select',
                'placeholder': 'Привод'
            }),
            "storage_performance": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'Производительность (м3/мин)'
            }),
            "storage_power": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'Мощность (кВт)'
            }),
            "storage_outlet_pipe_diameter": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'Диаметр выходной трубы'
            }),
            "storage_dimensions": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'Габариты ШхВхГ (мм)'
            }),
            "storage_mass": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'Масса (кг)'
            }),
            "storage_number": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'На складе'
            }),
            "storage_reserv_number": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'Из них в резерве'
            }),
            "storage_image": TextInput(attrs={
                'class': 'form-control',
                'type': 'text',
                'placeholder': 'Ссылка на изображение'
            }),
        }

class EquipmentForm(ModelForm):
    class Meta:
        model = Equipment
        fields = ['equipment_equipment', 'equipment_client', 'equipment_number']

        widgets = {
            "equipment_equipment": Select(attrs={
                'class': 'form-select',
                'aria-label': 'Default select example',
                'type': 'select',
                'placeholder': 'Выберите оборудование'
            }),
            "equipment_client": Select(attrs={
                'class': 'form-select',
                'aria-label': 'Default select example',
                'type': 'select',
                'placeholder': 'Выберите клиента'
            }),
            "equipment_number": TextInput(attrs={
                'class': 'form-control',
                'aria-label': 'Default select example',
                'type': 'number',
                'min': '1',
                'value': '1',
                'placeholder': 'Выберите клиента'
            }),
        }
