from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from main.models import Clients 
from main.models import History 


class Command(BaseCommand):

    def handle(self, *args, **options):
        print ('Поиск истекших дат бронирования')
        clients_check = Clients.objects.filter(clients_deletedate=timezone.now())
        if clients_check:
            for clients_list in clients_check:
                print ('Для клиента ' + str(clients_list) + ' дата бронирования истекла')
                print ('Копирование клиента в историю')
                History.objects.create(
                    history_name=clients_list.clients_name,
                    history_tin=clients_list.clients_tin,
                    history_city=clients_list.clients_city,
                    history_equipment=clients_list.clients_equipment,
                    history_dealer=clients_list.clients_dealer,
                    history_createdate=clients_list.clients_createdate,
                    history_deletedate=clients_list.clients_deletedate,
                    history_status='Снят с резерва',
                    )
                print ('Клиент успешно скопирован')
            print ('Удаляем клиентов из активных сделок')
            Clients.objects.filter(clients_deletedate=timezone.now()).delete()
            print ('Выполнено')
        else:
            print ('На сегодня истекших дат нет')