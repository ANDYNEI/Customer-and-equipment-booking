from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from main.models import Equipment


class Command(BaseCommand):

    def handle(self, *args, **options):
        print ('Поиск истекших дат бронирования')
        equipment_check = Equipment.objects.filter(equipment_deletedate=timezone.now())
        if equipment_check:
            Equipment.objects.filter(equipment_deletedate=timezone.now()).delete()
            print ('Выполнено')
        else:
            print ('На сегодня истекших дат нет')