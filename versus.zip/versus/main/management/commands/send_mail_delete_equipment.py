import smtplib
import time
from django.core.management.base import BaseCommand
from django.db import models
from django.utils import timezone
from datetime import timedelta
from main.models import Equipment
from django.contrib.auth.models import User
from django.core.mail import send_mail, get_connection, EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings


class Command(BaseCommand):
    help = 'Send message'

    def handle(self, *args, **options):
        print ('Поиск клиентов, дилеров которых необходимо уведомить')
        SendDate = Equipment.objects.filter(equipment_deletedate=timezone.now()+timedelta(days=1))
        connection = get_connection(
            host='smtp.mail.ru',
            port=465,
            username='dealer@air-part.ru',
            password='4QTDBzf5',
            use_tls=False,
            use_ssl=True,
        )
        if SendDate:
            print ('Получаем список клиетов по которым необходима рассылка')
            for SendMail in SendDate:
                print ('Дилеру ' + str(SendMail.equipment_dealer) + ' по клиенту ' + str(SendMail.equipment_client.clients_name) + ' необходимо отправить уведомление')
                subject = ('Дилерский портал Эир-Парт | Остался один день до конца бронирования ' + str(SendMail.equipment_client.clients_name))
                from_email = ('dealer@air-part.ru')
                to = str(SendMail.equipment_dealer.email)
                text_content = '<p>Уважаемый, <strong>' + str(SendMail.equipment_dealer.last_name) + ' ' + str(SendMail.equipment_dealer.first_name) + '</strong>.</p><br><p>Срок бронирования оборудования <strong>' + str(SendMail.equipment_client.clients_name) + '</strong> почти истек. Бронирование оборудования снимается автоматически.'
                html_content = '<p>Уважаемый, <strong>' + str(SendMail.equipment_dealer.last_name) + ' ' + str(SendMail.equipment_dealer.first_name) + '</strong>.</p><br><p>Срок бронирования оборудования <strong>' + str(SendMail.equipment_client.clients_name) + '</strong> почти истек. Бронирование оборудования снимается автоматически.'
                msg = EmailMultiAlternatives(subject, text_content, from_email, [to], connection=connection)
                msg.attach_alternative(html_content, "text/html")
                msg.send()
                time.sleep(60)
            print ('Сообщения успешно отправлены')
        else:
            print ('Нет подходящих компаний для уведомления')
            