import smtplib
import time
from django.core.management.base import BaseCommand
from django.db import models
from django.utils import timezone
from datetime import timedelta
from main.models import Clients
from django.contrib.auth.models import User
from django.core.mail import send_mail, get_connection, EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings


class Command(BaseCommand):
    help = 'Send message'

    def handle(self, *args, **options):
        print ('Поиск клиентов, дилеров которых необходимо уведомить')
        SendDate = Clients.objects.filter(clients_deletedate=timezone.now()+timedelta(days=10))
        connection = get_connection(
            host='smtp.mail.ru',
            port=465,
            username='dealer@air-part.ru',
            password='4QTDBzf5',
            use_tls=False,
            use_ssl=True,
        )
        if SendDate:
            print ('Получаем список клиетов по которым необходима рассылка')
            for SendMail in SendDate:
                print ('Дилеру ' + str(SendMail.clients_dealer) + ' по клиенту ' + str(SendMail.clients_name) + ' необходимо отправить уведомление')
                subject = ('Дилерский портал Эир-Парт | Осталось 10 дней до конца бронирования ' + str(SendMail.clients_name))
                from_email = ('dealer@air-part.ru')
                to = str(SendMail.clients_dealer.email)
                text_content = '<p>Уважаемый, <strong>' + str(SendMail.clients_dealer.last_name) + ' ' + str(SendMail.clients_dealer.first_name) + '</strong>.</p><br><p>Срок бронирования клиента <strong>' + str(SendMail.clients_name) + '</strong> почти истек, продлите бронь</p><br><p><strong>Название:</strong> ' + str(SendMail.clients_name) + '</p><p><strong>ИНН:</strong> ' + str(SendMail.clients_tin) + '</p><p><strong>Город:</strong> ' + str(SendMail.clients_city) + '</p><p><strong>Оборудование:</strong> ' + str(SendMail.clients_equipment) + '</p><p><strong>Дата снятия брони:</strong> ' + str(SendMail.clients_deletedate) + '</p>'
                html_content = '<p>Уважаемый, <strong>' + str(SendMail.clients_dealer.last_name) + ' ' + str(SendMail.clients_dealer.first_name) + '</strong>.</p><br><p>Срок бронирования клиента <strong>' + str(SendMail.clients_name) + '</strong> почти истек, продлите бронь</p><br><p><strong>Название:</strong> <a href="http://dealer.air-part.ru/clients/">' + str(SendMail.clients_name) + '</a></p><p><strong>ИНН:</strong> ' + str(SendMail.clients_tin) + '</p><p><strong>Город:</strong> ' + str(SendMail.clients_city) + '</p><p><strong>Оборудование:</strong> ' + str(SendMail.clients_equipment) + '</p><p><strong>Дата снятия брони:</strong> ' + str(SendMail.clients_deletedate) + '</p></p><br><br><p><strong>Для продления бронирования перейдите по <a href="http://dealer.air-part.ru/clients/">ссылке</a> и напротив данной компании нажмите на кнопку продления</strong>'
                msg = EmailMultiAlternatives(subject, text_content, from_email, [to], connection=connection)
                msg.attach_alternative(html_content, "text/html")
                msg.send()
                time.sleep(60)
            print ('Сообщения успешно отправлены')
        else:
            print ('Нет подходящих компаний для уведомления')
            