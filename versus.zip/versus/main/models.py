from django.db import models
from datetime import datetime, timedelta
from django.utils import timezone
import getpass
from django.contrib.auth.models import User, AbstractUser

class Clients(models.Model):
    clients_name = models.CharField('Название компании', max_length=50)
    clients_tin = models.CharField('ИНН', max_length=12, unique=True)
    clients_city = models.CharField('Город', max_length=30)
    clients_equipment = models.CharField('Оборудование', max_length=50)
    clients_dealer = models.ForeignKey(User, verbose_name='Дилер', on_delete=models.CASCADE, max_length=50)
    clients_createdate = models.DateField(verbose_name='Дата бронирования', default=(timezone.localtime(timezone.now()).strftime('%Y-%m-%d')), max_length=50)
    clients_deletedate = models.DateField(verbose_name='Дата снятия брони', default=(timezone.localtime(timezone.now()+timedelta(days=30)).strftime('%Y-%m-%d')), max_length=50)
    clients_status = models.CharField('Статус', default=('В работе'), max_length=30)

    def __str__(self):
        return self.clients_name

    class Meta:
        verbose_name = 'Клиента'
        verbose_name_plural = 'Клиенты'

class Storage(models.Model):
    
    STORAGE_CATEGORY_CHOICES = (
     ('Винтовой компрессор', 'Винтовой компрессор'),
     ('Осушитель сжатого воздуха', 'Осушитель сжатого воздуха'),
    )
    
    STORAGE_IP_CHOICES = (
     ('23', '23'),
     ('54', '54'),
    )
    
    STORAGE_PRESSURE_CHOICES = (
     ('8', '8'),
     ('10', '10'),
     ('13', '13'),
    )
    
    STORAGE_DRIVE_UNIT_CHOICES = (
     ('Ременной', 'Ременной'),
     ('Прямой', 'Прямой'),
    )

    storage_name = models.CharField('Оборудование', max_length=30)
    storage_bar = models.CharField('Давление', max_length=12, choices=STORAGE_PRESSURE_CHOICES)
    storage_ip = models.CharField('IP', max_length=12, choices=STORAGE_IP_CHOICES)
    storage_category = models.CharField('Категория', max_length=50, choices=STORAGE_CATEGORY_CHOICES)
    storage_drive_unit = models.CharField('Привод', max_length=12, choices=STORAGE_DRIVE_UNIT_CHOICES)
    storage_performance = models.CharField('Производительность', max_length=12)
    storage_power = models.CharField('Мощность', max_length=12)
    storage_outlet_pipe_diameter = models.CharField('Диаметр выходной трубы', max_length=12)
    storage_dimensions = models.CharField('Габариты', max_length=15)
    storage_mass = models.CharField('Масса', max_length=12)
    storage_number = models.IntegerField('На складе')
    storage_reserv_number = models.IntegerField('Из них в резерве')
    storage_waiting_number = models.IntegerField('Ожидается поставка')
    storage_waiting_reserv_number = models.IntegerField('Резерв в поставке')
    storage_waiting_date = models.DateField(verbose_name='Дата поставки', default=(timezone.localtime(timezone.now()).strftime('%Y-%m-%d')), max_length=50)
    storage_image = models.CharField('Изображение', max_length=255)

    def __str__(self):
        return str(self.storage_category + " " + self.storage_name + " (" + self.storage_bar + " бар) (IP " + self.storage_ip + ")")

    class Meta:
        unique_together = ('storage_name', 'storage_bar', 'storage_ip')
        verbose_name = 'Склад'
        verbose_name_plural = 'Склад'

class Equipment(models.Model):
    equipment_client = models.ForeignKey(Clients, verbose_name='Клиент', on_delete=models.CASCADE, max_length=50)
    equipment_equipment = models.ForeignKey(Storage, verbose_name='Оборудование', on_delete=models.CASCADE, max_length=50)
    equipment_dealer = models.ForeignKey(User, verbose_name='Дилер', on_delete=models.CASCADE, max_length=50)
    equipment_number = models.IntegerField('Количество')
    equipment_createdate = models.DateField(verbose_name='Дата бронирования', default=(timezone.localtime(timezone.now()).strftime('%Y-%m-%d')), max_length=50)
    equipment_deletedate = models.DateField(verbose_name='Дата снятия брони', default=(timezone.localtime(timezone.now()+timedelta(days=7)).strftime('%Y-%m-%d')), max_length=50)

    def __str__(self):
        return self.equipment_dealer.username

    class Meta:
        unique_together = ('equipment_client', 'equipment_equipment')
        verbose_name = 'Оборудование'
        verbose_name_plural = 'Оборудование'

class History(models.Model):
    history_name = models.CharField('Название компании', max_length=50)
    history_tin = models.CharField('ИНН', max_length=12)
    history_city = models.CharField('Город', max_length=30)
    history_equipment = models.CharField('Оборудование', max_length=50)
    history_dealer = models.ForeignKey(User, verbose_name='Дилер', on_delete=models.CASCADE, max_length=50)
    history_createdate = models.DateField(verbose_name='Дата бронирования', max_length=50)
    history_deletedate = models.DateField(verbose_name='Дата снятия брони', max_length=50)
    history_status = models.CharField('Статус', default=('В работе'), max_length=30)
 
    def __str__(self):
        return self.history_name

    class Meta:
        verbose_name = 'Историю'
        verbose_name_plural = 'История'