from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.index),
    path('clients/', views.clients),
    path('equipment/', views.equipment),
    path('storage/', views.storage),
    path('storage/waiting/', views.storagewaiting),
    path('files/', views.files),
    path('history/', views.history),
    path('backoffice/clients/', views.backofficeclients),
    path('backoffice/dealers/', views.backofficedealers),
    path('backoffice/staff/', views.backofficestaff),
    path('backoffice/storage/', views.backofficestorage),
    path('backoffice/history/', views.backofficehistory),
    path('user/<str:username>/', views.userprofile),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('password-change/', auth_views.PasswordChangeView.as_view(), name='password_change'),
    path('password-change/done/', auth_views.PasswordChangeDoneView.as_view(), name='password_change_done'),
]