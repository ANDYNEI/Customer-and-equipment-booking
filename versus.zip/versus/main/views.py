from django.shortcuts import render, redirect
from datetime import datetime, timedelta
from django.utils import timezone
from .forms import *
from .models import *
from django.contrib.auth.models import User, AbstractUser

def index(request):
    return render(request, 'main/index.html')

def clients(request):
    error = ''
    added = ''
    fatalError = ''
    viewClients = Clients.objects.order_by('-clients_createdate').filter(clients_dealer__username=request.user)

    if request.method == 'POST' and 'clients_save' in request.POST:
        form = ClientsForm(request.POST)
        if form.is_valid():
            form.instance.clients_dealer = request.user
            form.save()
            added = 'Клиент успешно забронирован'
        else:
            error = 'Данный клиент забронирован'

    if request.method == 'POST' and 'clients_extend' in request.POST:
        ClientExtendId = int(request.POST['clients_extend'])
        SuccessExtendDate = Clients.objects.filter(clients_deletedate__lte=timezone.now()+timedelta(days=10), id=ClientExtendId)
        
        if SuccessExtendDate:
            Clients.objects.filter(id=ClientExtendId).update(clients_deletedate=timezone.now()+timedelta(days=30))
            added = 'Вы успешно продлили бронирование для клиента на 30 календарных дней'
        else:
            error = 'Клиента можно продлить только за 10 дней до снятия брони'

    if request.method == 'POST' and 'clients_sale' in request.POST:
        ClientExtendId = int(request.POST['clients_sale'])
        ClientsModel = Clients.objects.filter(id=ClientExtendId)
        
        if ClientExtendId:
            for ClientsList in ClientsModel:
                History.objects.create(
                    history_name=ClientsList.clients_name,
                    history_tin=ClientsList.clients_tin,
                    history_city=ClientsList.clients_city,
                    history_equipment=ClientsList.clients_equipment,
                    history_dealer=ClientsList.clients_dealer,
                    history_createdate=ClientsList.clients_createdate,
                    history_deletedate=ClientsList.clients_deletedate,
                    history_status='Успешная продажа',
                    )
            Clients.objects.filter(id=ClientExtendId).delete()
            added = 'Сделка перенесена в историю'
        else:
            error = 'Неизвестная ошибка'

    if request.method == 'POST' and 'clients_cancel' in request.POST:
        ClientExtendId = int(request.POST['clients_cancel'])
        ClientsModel = Clients.objects.filter(id=ClientExtendId)
        
        if ClientExtendId:
            for ClientsList in ClientsModel:
                History.objects.create(
                    history_name=ClientsList.clients_name,
                    history_tin=ClientsList.clients_tin,
                    history_city=ClientsList.clients_city,
                    history_equipment=ClientsList.clients_equipment,
                    history_dealer=ClientsList.clients_dealer,
                    history_createdate=ClientsList.clients_createdate,
                    history_deletedate=ClientsList.clients_deletedate,
                    history_status='Сделка отменена',
                    )
            Clients.objects.filter(id=ClientExtendId).delete()
            added = 'Сделка отменена и перенесена в историю'
        else:
            error = 'Неизвестная ошибка'
    
    form = ClientsForm()

    data = {
        'form': form,
        'added': added,
        'error': error,
        'viewClients': viewClients
    }

    return render(request, 'main/clients.html', data)

def storage(request):
    error = ''
    added = ''
    viewStorage = Storage.objects.order_by('storage_performance').filter(storage_number__gte=1)

    data = {
        'added': added,
        'error': error,
        'viewStorage': viewStorage
    }

    return render(request, 'main/storage.html', data)

def storagewaiting(request):
    error = ''
    added = ''
    viewStorage = Storage.objects.order_by('storage_performance').filter(storage_waiting_number__gte=1)

    data = {
        'added': added,
        'error': error,
        'viewStorage': viewStorage
    }

    return render(request, 'main/storage_waiting.html', data)


def equipment(request):
    error = ''
    added = ''
    viewEquipment = Equipment.objects.order_by('-equipment_createdate').filter(equipment_dealer__username=request.user)
    viewStorage = Storage.objects.all()

    if request.method == 'POST':
        form = EquipmentForm(request.POST)
        if form.is_valid():
            form.instance.equipment_dealer = request.user
            form.save()
            added = 'Оборудование успешно зарезервировано'
        else:
            error = 'Вы уже зарезервировали данное оборудование и компанию'
    
    form = EquipmentForm()
    form.fields["equipment_client"].queryset= Clients.objects.filter(clients_dealer__username=request.user)
    form.fields["equipment_equipment"].queryset= Storage.objects.filter(storage_number__gte=1)

    data = {
        'form': form,
        'added': added,
        'error': error,
        'viewEquipment': viewEquipment,
        'viewStorage': viewStorage,
    }

    return render(request, 'main/equipment.html', data)

def files(request):
    return render(request, 'main/files.html')

def backofficeclients(request):
    viewClients = Clients.objects.order_by('-clients_createdate')

    data = {
        'viewClients': viewClients
    }

    return render(request, 'main/backoffice_clients.html', data)

def history(request):
    viewHistory= History.objects.order_by('-history_createdate').filter(history_dealer__username=request.user)

    data = {
        'viewHistory': viewHistory
    }

    return render(request, 'main/history.html', data)

def backofficedealers(request):
    viewDealers = User.objects.all().exclude(llc_name='ООО "Эир-парт"').order_by('llc_name')

    data = {
        'viewDealers': viewDealers
    }

    return render(request, 'main/backoffice_dealers.html', data)

def backofficestaff(request):
    viewStaff = User.objects.all().filter(llc_name='ООО "Эир-парт"').order_by('last_name')

    data = {
        'viewStaff': viewStaff
    }

    return render(request, 'main/backoffice_staff.html', data)

def backofficestorage(request):
    added = ''
    error = ''
    viewStorage = Storage.objects.order_by('storage_performance')

    if request.method == 'POST' and 'storage_save' in request.POST:
        form = BackStorageForm(request.POST)
        if form.is_valid():
            form.save()
            added = 'Оборудование успешно добавлено'
        else:
            error = 'Оборудование уже существует'

    form = BackStorageForm()

    data = {
        'form': form,
        'added': added,
        'error': error,
        'viewStorage': viewStorage,
    }

    return render(request, 'main/backoffice_storage.html', data)

def backofficehistory(request):
    viewHistory= History.objects.order_by('-history_createdate')

    data = {
        'viewHistory': viewHistory
    }

    return render(request, 'main/backoffice_history.html', data)

def userprofile(request, username):
    userView = User.objects.filter(username=username)

    data = {
        'userView': userView
    }

    return render(request, 'main/profile.html', data)